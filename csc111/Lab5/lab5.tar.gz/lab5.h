void swap1(int, int);  //Prototype for lab 5 a swap function
void swap2(int*, int*);//Prototype for lab 5 b swap function
void swap3(int, int*); //Prototype for lab 5 c swap function
void swap4(int*, int); //Prototype for lab 5 d swap function

