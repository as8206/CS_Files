/*CSC111 Computer Science 2
  Lab 13: Pig Latin Strings
  Programmers: Mike and Andrew
  Professor: Dr. Lee
  Date Updated: April 13, 2017
  Date Created: April 13, 2017
*/


typedef enum {FALSE, TRUE} Bool;                 //creates boolean type

//int startsWithVowel(char *);
Bool startsWithVowel(char *);

void moveChar(char *);

//int checkForY(char *);
Bool checkForY(char *);
