/* Lab2: p68n1c.c
   Programmer: Andrew Stake
   Class: CS2
   Professor: Dr. Jeonghwa Lee
   File Created: January 31, 2017
   File Updated: January 31, 2017
*/

#include<stdio.h>

int main()
{
   int i = 7, j = 8, k = 9;
   
   printf("%d\n", (i + 10) % k / j);
  
   return 0;
}
