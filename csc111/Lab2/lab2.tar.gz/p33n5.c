/* Lab2: p33n5.c
   Programmer: Andrew Stake
   Class: CS2
   Professor: Dr. Jeonghwa Lee
   File Created: January 31, 2017
   File Updated: January 31, 2017
*/

#include<stdio.h>

int main()
{
   //int 100_bottles = 1;
   int _100_bottles = 2;
   int one_hundred_bottles = 3;
   int bottles_by_the_hundred_ = 4;

   //printf("%d\n", 100_bottles);   
   printf("%d\n", _100_bottles);
   printf("%d\n", one_hundred_bottles);
   printf("%d\n", bottles_by_the_hundred_);
  
   return 0;
}
