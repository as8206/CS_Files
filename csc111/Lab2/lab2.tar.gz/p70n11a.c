/* Lab2: p70n11a.c
   Programmer: Andrew Stake
   Class: CS2
   Professor: Dr. Jeonghwa Lee
   File Created: January 31, 2017
   File Updated: January 31, 2017
*/

#include<stdio.h>

int main()
{
   int i = 1;
   
   printf("%d ", i++ - i);
   printf("%d\n", i);
  
   return 0;
}
