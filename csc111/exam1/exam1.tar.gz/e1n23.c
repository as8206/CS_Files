/* Exam 1
   Programmer: Andrew Stake
   Class: CS2
   Professor: Dr. Lee
   File Created: Feb 28, 2017
   File Updated: Feb 28, 2017
*/

//--- Source code of exam1.c
//--- Compile: gcc -o exam1 exam1.c

#include<stdio.h>

int main(int argc, char*argv[])          //Code directly given from question 
{
   printf("argc = %d \n", argc);
   printf("argv[3] = %s \n", argv[3]);

   return 0;
}
