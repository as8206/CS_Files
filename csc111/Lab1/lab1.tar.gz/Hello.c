#include <stdio.h>

int main()
{
   printf("Welcome to CS2\n");
  
   return 0;
}
