/* Lab: Lab 4
   Programmers: Spencer Hooper, Andrew S, and Christian C.
   Professor: Dr. Lee
   File Created: 02/14/2017
   File Updated: 02/14/2017
*/
int lab4a(int);     //prototype function call for lab4a
int lab4b(int);     //prototype function call for lab4b
