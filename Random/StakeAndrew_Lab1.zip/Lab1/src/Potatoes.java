/**
 * This program prints out the words to a rhyme used
 * by children to select someone.
 * @author Dr. Wellington
 * Andrew Stake
 */
public class Potatoes 
{
	/**
	 * The sequence of instructions that should
	 * execute when we run the program
	 * 
	 * @param args just ignore these for now!
	 */
	public static void main(String[] args)
	{
		int potatoNumber;
		
		potatoNumber = 1;
		while (potatoNumber < 8)
		{
			System.out.println(potatoNumber);
			if (potatoNumber != 4)
			{
				System.out.println(" potato");
			}
			System.out.println("");
			
			potatoNumber = potatoNumber + 1;
		}
		System.out.println("More");
		System.out.println("You're out!");
	}
}
